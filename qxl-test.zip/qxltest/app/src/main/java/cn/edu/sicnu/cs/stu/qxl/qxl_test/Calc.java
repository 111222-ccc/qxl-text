package cn.edu.sicnu.cs.stu.qxl.qxl_test;

public class Calc {
    public static double calculate(double a, double b, String op) throws ArithmeticException {
        double res;
        switch (op) {
            case "+":
                res = a + b;
                break;
            case "-":
                res = a - b;
                break;
            case "*":
                res = a * b;
                break;
            case "/":
                if (b == 0) {
                    throw new ArithmeticException("除数不能为0");
                }
                res = a / b;
                break;
            default:
                res = 0;
        }
        return res;
    }
}
