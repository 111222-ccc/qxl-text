package cn.edu.sicnu.cs.stu.qxl.qxl_test

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.ArrayList

class MainActivity : AppCompatActivity() {
    private lateinit var etNum1: EditText
    private lateinit var etNum2: EditText
    private lateinit var rgOp: RadioGroup
    private lateinit var tvResult: TextView
    private lateinit var btnCalc: Button
    private lateinit var btnHistory: Button

    private lateinit var sp: SharedPreferences

    companion object {
        @JvmField
        val historyList = ArrayList<HistoryBean>()
        private const val SP_NAME = "calc_history"
        private const val SP_KEY = "history_data"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "齐新路 2024110127"

        sp = getSharedPreferences(SP_NAME, MODE_PRIVATE)
        // 读取本地永久保存的历史记录
        loadHistoryFromSp()

        etNum1 = findViewById(R.id.et_num1)
        etNum2 = findViewById(R.id.et_num2)
        rgOp = findViewById(R.id.rg_op)
        tvResult = findViewById(R.id.tv_result)
        btnCalc = findViewById(R.id.btn_calc)
        btnHistory = findViewById(R.id.btn_history)

        btnCalc.setOnClickListener {
            doCalc()
        }
        btnHistory.setOnClickListener {
            val intent = Intent(this, HistoryActivity::class.java)
            startActivity(intent)
        }
    }

    //从SharedPreferences读取历史
    private fun loadHistoryFromSp() {
        historyList.clear()
        val savedText = sp.getString(SP_KEY, "") ?: ""
        if(savedText.isNotEmpty()){
            val arr = savedText.split("|||")
            for(s in arr){
                if(s.isNotBlank()){
                    historyList.add(HistoryBean.fromSaveString(s))
                }
            }
        }
    }

    //保存历史到SharedPreferences
    private fun saveHistoryToSp(){
        val sb = StringBuilder()
        for(item in historyList){
            sb.append(item.toSaveString())
            sb.append("|||") //分隔符
        }
        sp.edit()
            .putString(SP_KEY, sb.toString())
            .apply()
    }


    private fun doCalc() {
        val s1 = etNum1.text.toString().trim()
        val s2 = etNum2.text.toString().trim()
        if (s1.isEmpty() || s2.isEmpty()) {
            Toast.makeText(this, "请输入两个数字", Toast.LENGTH_SHORT).show()
            return
        }
        val checkedId = rgOp.checkedRadioButtonId
        if (checkedId == -1) {
            Toast.makeText(this, "请选择运算符", Toast.LENGTH_SHORT).show()
            return
        }
        val rb: RadioButton = findViewById(checkedId)
        val op = rb.text.toString()

        try {
            val a = s1.toDouble()
            val b = s2.toDouble()
            val result = Calc.calculate(a, b, op)
            val resText = "$a$op$b=$result"
            tvResult.text = "结果：$resText"

            //新增记录
            historyList.add(HistoryBean(resText))
            //立刻永久保存到本地
            saveHistoryToSp()

        } catch (e: NumberFormatException) {
            Toast.makeText(this, "数字格式错误", Toast.LENGTH_SHORT).show()
        } catch (e: ArithmeticException) {
            Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.item_history) {
            val intent = Intent(this, HistoryActivity::class.java)
            startActivity(intent)
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
