package cn.edu.sicnu.cs.stu.qxl.qxl_test;

import java.io.Serializable;

public class HistoryBean implements Serializable {
    private String expression;

    public HistoryBean(String expression) {
        this.expression = expression;
    }

    public String getExpression() {
        return expression;
    }

    //转为字符串用于持久化存储
    public String toSaveString(){
        return expression;
    }

    //从字符串构建对象
    public static HistoryBean fromSaveString(String str){
        return new HistoryBean(str);
    }
}
